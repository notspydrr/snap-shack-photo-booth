(() => {
  'use strict';

  /* ================= Filter presets =================
     Each preset is a list of ops shared by the CSS preview and the
     pixel pipeline, so what you see is what you capture. */
  const PRESETS = [
    { id: 'natural', name: 'Natural', ops: [] },
    { id: 'mono', name: 'Booth B&W', ops: [['grayscale', 1], ['contrast', 1.2], ['brightness', 1.05]], vignette: 0.35 },
    { id: 'vintage', name: 'Vintage', ops: [['sepia', 0.55], ['contrast', 1.05], ['saturate', 1.2], ['brightness', 1.05]], tint: ['#ffb36b', 0.45], vignette: 0.45 },
    { id: 'pop', name: 'Pop', ops: [['saturate', 1.9], ['contrast', 1.15]] },
    { id: 'bubblegum', name: 'Bubblegum', ops: [['hue-rotate', -20], ['saturate', 1.35], ['brightness', 1.08]], tint: ['#ff5fa2', 0.6] },
    { id: 'ice', name: 'Ice', ops: [['saturate', 0.8], ['contrast', 1.05], ['brightness', 1.05]], tint: ['#3fb6ff', 0.65] },
    { id: 'golden', name: 'Golden', ops: [['sepia', 0.3], ['saturate', 1.4], ['brightness', 1.08]], tint: ['#ffcc33', 0.5], vignette: 0.25 },
    { id: 'noir', name: 'Noir', ops: [['grayscale', 1], ['contrast', 1.7], ['brightness', 0.9]], vignette: 0.6 },
    { id: 'alien', name: 'Alien', ops: [['hue-rotate', 110], ['saturate', 1.6]] },
    { id: 'xray', name: 'X-Ray', ops: [['invert', 1], ['hue-rotate', 180], ['saturate', 1.3]] },
  ];

  const opToCss = ([k, v]) => k === 'hue-rotate' ? `hue-rotate(${v}deg)` : `${k}(${v})`;
  const presetCss = (p) => p.ops.length ? p.ops.map(opToCss).join(' ') : 'none';
  const vignetteCss = (a) => `radial-gradient(ellipse at center, rgba(0,0,0,0) 52%, rgba(0,0,0,${a}) 100%)`;

  /* ================= DOM ================= */
  const $ = (id) => document.getElementById(id);
  const app = $('app'), vf = $('vf'), video = $('video');
  const fxTint = $('fxTint'), fxVignette = $('fxVignette'), filterName = $('filterName');
  const panel = $('panel'), panelArt = $('panelArt'), panelTitle = $('panelTitle'), panelText = $('panelText'), panelActions = $('panelActions');
  const statusText = $('statusText');
  const shutter = $('shutter'), timerBtn = $('timerBtn'), timerLabel = $('timerLabel'), modeBtn = $('modeBtn'), modeLabel = $('modeLabel');
  const flipBtn = $('flipBtn'), stopBtn = $('stopBtn'), mirrorBtn = $('mirrorBtn'), soundBtn = $('soundBtn');
  const filterRow = $('filterRow'), countdownEl = $('countdown'), stripProgress = $('stripProgress'), flash = $('flash');
  const gallery = $('gallery'), galleryEmpty = $('galleryEmpty'), galleryCount = $('galleryCount'), clearBtn = $('clearBtn');
  const viewer = $('viewer'), viewerImg = $('viewerImg'), viewerMeta = $('viewerMeta'), dlBtn = $('dlBtn'), shareBtn = $('shareBtn'), delBtn = $('delBtn');
  const toastEl = $('toast'), work = $('work');

  /* ================= State ================= */
  const state = {
    cam: 'idle',          // idle | requesting | live | demo | denied | notfound | inuse | unsupported | error | paused
    stream: null,
    facing: 'user',
    deviceId: null,
    videoInputs: [],
    mirror: true,
    sound: true,
    timer: 3,             // 0 | 3 | 5 | 10
    mode: 'single',       // single | strip
    preset: PRESETS[0],
    busy: false,
    cancel: false,
    shots: [],
    viewing: null,
    demoRaf: 0,
    resumeOnVisible: false,
  };
  const TIMERS = [3, 5, 10, 0];
  const MAX_SHOTS = 24;

  /* ================= Utility ================= */
  let toastTimer;
  function toast(msg) {
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove('show'), 2400);
  }
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const pad = (n) => String(n).padStart(2, '0');
  const stamp = (d) => `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;

  /* ================= Sound ================= */
  let actx;
  function audio() {
    if (!state.sound) return null;
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      if (actx.state === 'suspended') actx.resume();
      return actx;
    } catch { return null; }
  }
  function beep(freq = 880, dur = 0.12, vol = 0.18) {
    const a = audio(); if (!a) return;
    const o = a.createOscillator(), g = a.createGain();
    o.type = 'triangle'; o.frequency.value = freq;
    g.gain.setValueAtTime(vol, a.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, a.currentTime + dur);
    o.connect(g).connect(a.destination); o.start(); o.stop(a.currentTime + dur);
  }
  function shutterSound() {
    const a = audio(); if (!a) return;
    const len = Math.floor(a.sampleRate * 0.12);
    const buf = a.createBuffer(1, len, a.sampleRate), d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3);
    const src = a.createBufferSource(), f = a.createBiquadFilter(), g = a.createGain();
    f.type = 'highpass'; f.frequency.value = 1200; g.gain.value = 0.5;
    src.buffer = buf; src.connect(f).connect(g).connect(a.destination); src.start();
  }

  /* ================= Camera state UI ================= */
  const ART = {
    camera: `<svg class="bob" width="76" height="70" viewBox="0 0 76 70" fill="none" stroke="#1f1a24" stroke-width="3" stroke-linejoin="round"><rect x="4" y="16" width="68" height="48" rx="10" fill="#ffc93c"/><path d="M24 16l5-9h18l5 9" fill="#ff7eb6"/><circle cx="38" cy="40" r="15" fill="#fffaf0"/><circle cx="38" cy="40" r="8" fill="#1f1a24"/><circle cx="34.5" cy="36.5" r="2.4" fill="#fffaf0" stroke="none"/><rect x="56" y="22" width="9" height="6" rx="2" fill="#d7263d"/></svg>`,
    wait: `<div class="spinner"></div>`,
    lock: `<svg class="bob" width="70" height="70" viewBox="0 0 70 70" fill="none" stroke="#1f1a24" stroke-width="3" stroke-linejoin="round"><rect x="12" y="30" width="46" height="34" rx="8" fill="#ff7eb6"/><path d="M22 30v-8a13 13 0 0126 0v8" fill="none"/><circle cx="35" cy="45" r="4.5" fill="#1f1a24"/><path d="M35 49v6" stroke-linecap="round"/></svg>`,
    ghost: `<svg class="bob" width="64" height="70" viewBox="0 0 64 70" fill="none" stroke="#1f1a24" stroke-width="3" stroke-linejoin="round"><path d="M8 32a24 24 0 0148 0v32l-8-6-8 6-8-6-8 6-8-6-8 6z" fill="#5ab8ff"/><circle cx="24" cy="32" r="4" fill="#1f1a24"/><circle cx="40" cy="32" r="4" fill="#1f1a24"/><path d="M27 44q5 4 10 0" stroke-linecap="round"/></svg>`,
    busy: `<svg class="bob" width="76" height="70" viewBox="0 0 76 70" fill="none" stroke="#1f1a24" stroke-width="3" stroke-linejoin="round"><rect x="4" y="16" width="68" height="48" rx="10" fill="#8d8590"/><circle cx="38" cy="40" r="15" fill="#fffaf0"/><path d="M30 32l16 16M46 32L30 48" stroke-linecap="round"/><text x="56" y="12" font-family="Chillax, sans-serif" font-size="14" font-weight="700" fill="#1f1a24" stroke="none">z</text><text x="64" y="6" font-family="Chillax, sans-serif" font-size="10" font-weight="700" fill="#1f1a24" stroke="none">z</text></svg>`,
    pause: `<svg class="bob" width="70" height="70" viewBox="0 0 70 70" fill="none" stroke="#1f1a24" stroke-width="3"><circle cx="35" cy="35" r="28" fill="#ffc93c"/><rect x="25" y="23" width="7" height="24" rx="2" fill="#1f1a24"/><rect x="38" y="23" width="7" height="24" rx="2" fill="#1f1a24"/></svg>`,
  };

  const STATUS_TEXT = {
    idle: 'Camera off', requesting: 'Asking…', live: 'Live', demo: 'Demo cam',
    denied: 'Blocked', notfound: 'No camera', inuse: 'In use', unsupported: 'No live cam', error: 'Error', paused: 'Paused',
  };

  function button(label, cls, onClick) {
    const b = document.createElement('button');
    b.className = `btn ${cls || ''}`; b.textContent = label; b.addEventListener('click', onClick);
    return b;
  }
  function linkButton(label, href) {
    const a = document.createElement('a');
    a.className = 'btn btn-ghost btn-small'; a.textContent = label; a.href = href; a.target = '_blank'; a.rel = 'noopener';
    return a;
  }
  const inFrame = (() => { try { return window.self !== window.top; } catch { return true; } })();

  function showPanel(art, title, html, actions) {
    panelArt.innerHTML = ART[art] || '';
    panelTitle.textContent = title;
    panelText.innerHTML = html;
    panelActions.replaceChildren(...actions);
    // retrigger entrance
    const card = panel.querySelector('.panel-card');
    card.style.animation = 'none'; void card.offsetWidth; card.style.animation = '';
  }

  function setCam(cam, detail) {
    state.cam = cam;
    app.dataset.cam = cam;
    statusText.textContent = STATUS_TEXT[cam] || cam;
    const active = cam === 'live' || cam === 'demo';
    shutter.disabled = !active;
    stopBtn.hidden = !active;
    $('nativeBtn').hidden = active;
    panel.setAttribute('aria-hidden', active ? 'true' : 'false');
    if (!active) { flipBtn.hidden = true; }

    const start = () => button('Turn on camera', 'btn-primary', () => startCamera());
    const demo = () => button('Try demo camera', 'btn-ghost btn-small', () => startDemo());
    const native = (primary) => button('Use phone camera', primary ? 'btn-primary' : '', () => openNativeCamera());
    const retry = () => button('Try again', 'btn-primary', () => startCamera());

    switch (cam) {
      case 'idle':
        showPanel('camera', 'Ready for your close-up?',
          'Turn on your camera to start snapping. Photos stay on your device — nothing is uploaded.',
          [start(), native(), demo()]);
        break;
      case 'requesting':
        showPanel('wait', 'Say yes to the camera',
          'Your browser is asking for permission. Tap <b>Allow</b> in the prompt to open the booth.',
          [button('Cancel', 'btn-ghost', () => { state.pendingCancel = true; setCam('idle'); })]);
        break;
      case 'denied': {
        const acts = [native(true), retry(), demo()];
        if (inFrame) acts.push(linkButton('Open booth in a new tab ↗', location.href));
        showPanel('lock', 'Camera access is blocked',
          `Tap <b>Use phone camera</b> to snap with your phone’s camera app, or allow live access:<ol>
            <li>Tap the <b>lock</b> or <b>aA</b> icon by the address bar.</li>
            <li>Set <b>Camera</b> to <b>Allow</b>, then tap Try again.</li>
          </ol>${inFrame ? '<br>If this booth is embedded in another page, opening it in its own tab usually helps.' : ''}`,
          acts);
        break;
      }
      case 'notfound':
        showPanel('ghost', 'No camera found',
          'We couldn’t spot a camera on this device. Plug one in or switch devices — or play with the demo camera.',
          [retry(), native(), demo()]);
        break;
      case 'inuse':
        showPanel('busy', 'Camera is busy',
          'Another app or tab is using the camera. Close it (video calls are the usual suspects) and try again.',
          [retry(), native(), demo()]);
        break;
      case 'unsupported':
        showPanel('ghost', window.isSecureContext === false ? 'Needs a secure page' : 'Snap with your phone camera',
          window.isSecureContext === false
            ? 'Browsers only allow the camera on <b>https://</b> pages. Open this booth over a secure link.'
            : 'Live preview isn’t available here, but you can still snap with your phone’s camera app — filters are added after.',
          [native(true), demo()]);
        break;
      case 'paused':
        showPanel('pause', 'Booth on pause',
          'We turned the camera off to save battery while you were away.',
          [button('Resume camera', 'btn-primary', () => startCamera()), native(), demo()]);
        break;
      case 'error':
        showPanel('ghost', 'Something went sideways',
          `The camera didn’t start${detail ? ` <small>(${String(detail).replace(/[^\w -]/g, '')})</small>` : ''}. Give it another go.`,
          [retry(), native(), demo()]);
        break;
      default: break;
    }
  }

  /* ================= Camera control ================= */
  function stopStream() {
    if (state.demoRaf) { cancelAnimationFrame(state.demoRaf); state.demoRaf = 0; }
    if (state.stream) state.stream.getTracks().forEach((t) => t.stop());
    state.stream = null;
    video.srcObject = null;
  }

  function classify(err) {
    const n = err && err.name;
    if (n === 'NotAllowedError' || n === 'PermissionDeniedError' || n === 'SecurityError') return 'denied';
    if (n === 'NotFoundError' || n === 'DevicesNotFoundError' || n === 'OverconstrainedError') return 'notfound';
    if (n === 'NotReadableError' || n === 'TrackStartError' || n === 'AbortError') return 'inuse';
    return 'error';
  }

  async function getStream(opts) {
    const base = { width: { ideal: 1920 }, height: { ideal: 1440 } };
    const video = opts.deviceId ? { ...base, deviceId: { exact: opts.deviceId } } : { ...base, facingMode: { ideal: opts.facing } };
    try {
      return await navigator.mediaDevices.getUserMedia({ video, audio: false });
    } catch (e) {
      if (e.name === 'OverconstrainedError' || e.name === 'ConstraintNotSatisfiedError') {
        return navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      }
      throw e;
    }
  }

  async function refreshDevices() {
    try {
      const list = await navigator.mediaDevices.enumerateDevices();
      state.videoInputs = list.filter((d) => d.kind === 'videoinput');
    } catch { state.videoInputs = []; }
    flipBtn.hidden = !(state.cam === 'live' && state.videoInputs.length > 1);
  }

  async function startCamera(opts = {}) {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { setCam('unsupported'); return; }
    if (!navigator.userActivation || navigator.userActivation.isActive) audio(); // unlock audio on user gesture
    stopStream();
    state.pendingCancel = false;
    if (!opts.silent) setCam('requesting');
    try {
      const stream = await getStream({ facing: opts.facing || state.facing, deviceId: opts.deviceId });
      if (state.pendingCancel) { stream.getTracks().forEach((t) => t.stop()); return; }
      await attach(stream);
      const track = stream.getVideoTracks()[0];
      const settings = track.getSettings ? track.getSettings() : {};
      state.deviceId = settings.deviceId || null;
      if (settings.facingMode) state.facing = settings.facingMode === 'environment' ? 'environment' : 'user';
      else if (opts.facing) state.facing = opts.facing;
      setMirror(state.facing === 'user');
      track.addEventListener('ended', () => { if (state.stream === stream) { stopStream(); setCam('error', 'camera disconnected'); } });
      setCam('live');
      await refreshDevices();
      updateThumbsSoon();
    } catch (err) {
      console.warn('Camera error', err);
      stopStream();
      setCam(classify(err), err && err.name);
    }
  }

  async function attach(stream) {
    state.stream = stream;
    video.srcObject = stream;
    await new Promise((res) => {
      if (video.readyState >= 2) return res();
      video.onloadeddata = () => res();
      setTimeout(res, 2500);
    });
    try { await video.play(); } catch { /* autoplay muted should pass */ }
  }

  async function flipCamera() {
    if (state.busy || state.cam !== 'live') return;
    flipBtn.classList.add('flipping');
    setTimeout(() => flipBtn.classList.remove('flipping'), 500);
    const prevId = state.deviceId;
    const nextFacing = state.facing === 'user' ? 'environment' : 'user';
    await startCamera({ facing: nextFacing, silent: true });
    // Some desktops ignore facingMode — cycle by deviceId instead.
    if (state.cam === 'live' && state.deviceId && state.deviceId === prevId && state.videoInputs.length > 1) {
      const i = state.videoInputs.findIndex((d) => d.deviceId === prevId);
      const next = state.videoInputs[(i + 1) % state.videoInputs.length];
      await startCamera({ deviceId: next.deviceId, silent: true });
    }
    toast(state.facing === 'user' ? 'Selfie camera' : 'Back camera');
  }

  /* ================= Demo camera ================= */
  function startDemo() {
    stopStream();
    audio();
    const c = document.createElement('canvas');
    c.width = 720; c.height = 960;
    const g = c.getContext('2d');
    if (!c.captureStream) { toast('Demo camera isn’t supported in this browser'); return; }
    const t0 = performance.now();
    const draw = (now) => {
      const t = (now - t0) / 1000;
      const grd = g.createLinearGradient(0, 0, 720, 960);
      grd.addColorStop(0, `hsl(${(t * 20) % 360} 80% 62%)`);
      grd.addColorStop(1, `hsl(${(t * 20 + 140) % 360} 75% 55%)`);
      g.fillStyle = grd; g.fillRect(0, 0, 720, 960);
      // confetti
      for (let i = 0; i < 26; i++) {
        const x = (i * 97 + t * (30 + (i % 5) * 12)) % 760 - 20;
        const y = (i * 151 + t * (50 + (i % 7) * 15)) % 1000 - 20;
        g.save(); g.translate(x, y); g.rotate(t * (i % 3 + 1));
        g.fillStyle = ['#ffc93c', '#fffaf0', '#1f1a24', '#ff7eb6', '#3ecf8e'][i % 5];
        g.fillRect(-9, -5, 18, 10); g.restore();
      }
      // character
      const bx = 360 + Math.sin(t * 1.3) * 60, by = 500 + Math.sin(t * 2.1) * 30;
      g.save(); g.translate(bx, by); g.rotate(Math.sin(t * 1.7) * 0.12);
      g.lineWidth = 10; g.strokeStyle = '#1f1a24';
      g.fillStyle = '#ffc93c'; g.beginPath(); g.arc(0, 0, 190, 0, Math.PI * 2); g.fill(); g.stroke();
      const blinkk = (t % 3.2) < 0.15 ? 0.1 : 1;
      g.fillStyle = '#1f1a24';
      g.beginPath(); g.ellipse(-65, -40, 22, 30 * blinkk, 0, 0, Math.PI * 2); g.fill();
      g.beginPath(); g.ellipse(65, -40, 22, 30 * blinkk, 0, 0, Math.PI * 2); g.fill();
      g.fillStyle = '#ff7eb6'; g.globalAlpha = .7;
      g.beginPath(); g.arc(-115, 30, 28, 0, 7); g.fill(); g.beginPath(); g.arc(115, 30, 28, 0, 7); g.fill();
      g.globalAlpha = 1;
      g.beginPath(); g.arc(0, 30, 90, 0.15 * Math.PI, 0.85 * Math.PI); g.stroke();
      g.restore();
      g.fillStyle = 'rgba(31,26,36,.75)'; g.font = '700 40px Chillax, sans-serif'; g.textAlign = 'center';
      g.fillText('DEMO CAM', 360, 900);
      state.demoRaf = requestAnimationFrame(draw);
    };
    state.demoRaf = requestAnimationFrame(draw);
    const stream = c.captureStream(30);
    attach(stream).then(() => {
      setMirror(false);
      setCam('demo');
      updateThumbsSoon();
      toast('Demo camera on — every feature works');
    });
  }

  /* ================= Filters ================= */
  let sampleUrl = null;
  function makeSample() {
    const c = document.createElement('canvas'); c.width = c.height = 112;
    const g = c.getContext('2d');
    const grd = g.createLinearGradient(0, 0, 112, 112);
    grd.addColorStop(0, '#ff9a5a'); grd.addColorStop(.5, '#ffd36b'); grd.addColorStop(1, '#5ab8ff');
    g.fillStyle = grd; g.fillRect(0, 0, 112, 112);
    g.fillStyle = '#ffe1c4'; g.strokeStyle = '#1f1a24'; g.lineWidth = 4;
    g.beginPath(); g.arc(56, 62, 32, 0, 7); g.fill(); g.stroke();
    g.fillStyle = '#1f1a24'; g.beginPath(); g.arc(45, 56, 4, 0, 7); g.arc(67, 56, 4, 0, 7); g.fill();
    g.beginPath(); g.arc(56, 66, 14, .2 * Math.PI, .8 * Math.PI); g.stroke();
    g.fillStyle = '#d7263d'; g.fillRect(0, 98, 112, 14);
    return c.toDataURL('image/jpeg', .85);
  }

  function buildFilters() {
    sampleUrl = makeSample();
    filterRow.replaceChildren(...PRESETS.map((p, i) => {
      const b = document.createElement('button');
      b.className = 'filter'; b.setAttribute('role', 'radio'); b.dataset.id = p.id;
      b.setAttribute('aria-checked', i === 0 ? 'true' : 'false'); b.tabIndex = i === 0 ? 0 : -1;
      b.innerHTML = `<span class="filter-thumb"><img alt="" src="${sampleUrl}" style="filter:${presetCss(p)}">
        <span class="t-tint" style="${p.tint ? `background:${p.tint[0]};opacity:${p.tint[1]}` : ''}"></span>
        <span class="t-vig" style="${p.vignette ? `background:${vignetteCss(p.vignette)}` : ''}"></span></span>
        <span class="filter-label">${p.name}</span>`;
      b.addEventListener('click', () => selectPreset(p, true));
      return b;
    }));
    filterRow.addEventListener('keydown', (e) => {
      if (!['ArrowRight', 'ArrowLeft'].includes(e.key)) return;
      e.preventDefault();
      const i = PRESETS.indexOf(state.preset) + (e.key === 'ArrowRight' ? 1 : -1);
      const p = PRESETS[(i + PRESETS.length) % PRESETS.length];
      selectPreset(p, true);
      filterRow.querySelector(`[data-id="${p.id}"]`).focus();
    });
  }

  let nameTimer;
  function selectPreset(p, announce) {
    state.preset = p;
    video.style.filter = presetCss(p);
    fxTint.style.background = p.tint ? p.tint[0] : 'transparent';
    fxTint.style.opacity = p.tint ? p.tint[1] : 0;
    fxVignette.style.background = p.vignette ? vignetteCss(p.vignette) : 'none';
    fxVignette.style.opacity = p.vignette ? 1 : 0;
    filterRow.querySelectorAll('.filter').forEach((el) => {
      const on = el.dataset.id === p.id;
      el.setAttribute('aria-checked', on ? 'true' : 'false'); el.tabIndex = on ? 0 : -1;
      if (on && announce) el.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
    });
    if (announce) {
      filterName.textContent = p.name;
      filterName.classList.add('show');
      clearTimeout(nameTimer);
      nameTimer = setTimeout(() => filterName.classList.remove('show'), 900);
    }
  }

  // Live-ish thumbnails from the camera feed
  let thumbTimer;
  function updateThumbsSoon() {
    clearTimeout(thumbTimer);
    thumbTimer = setTimeout(updateThumbs, 400);
  }
  function updateThumbs() {
    if (!(state.cam === 'live' || state.cam === 'demo') || !video.videoWidth) return;
    const c = document.createElement('canvas'); c.width = c.height = 112;
    const g = c.getContext('2d');
    const s = Math.min(video.videoWidth, video.videoHeight);
    if (state.mirror) { g.translate(112, 0); g.scale(-1, 1); }
    g.drawImage(video, (video.videoWidth - s) / 2, (video.videoHeight - s) / 2, s, s, 0, 0, 112, 112);
    let url;
    try { url = c.toDataURL('image/jpeg', .7); } catch { return; }
    filterRow.querySelectorAll('.filter-thumb img').forEach((img) => { img.src = url; });
    thumbTimer = setTimeout(updateThumbs, 5000);
  }

  /* ================= Pixel pipeline (fallback when ctx.filter is unsupported, e.g. Safari) ================= */
  const supportsCtxFilter = (() => {
    try { const g = document.createElement('canvas').getContext('2d'); g.filter = 'blur(1px)'; return g.filter === 'blur(1px)'; } catch { return false; }
  })();

  function matrixFor(k, v) {
    const s = 1 - v;
    if (k === 'saturate') return [.213 + .787 * v, .715 - .715 * v, .072 - .072 * v, .213 - .213 * v, .715 + .285 * v, .072 - .072 * v, .213 - .213 * v, .715 - .715 * v, .072 + .928 * v];
    if (k === 'grayscale') return [.2126 + .7874 * s, .7152 - .7152 * s, .0722 - .0722 * s, .2126 - .2126 * s, .7152 + .2848 * s, .0722 - .0722 * s, .2126 - .2126 * s, .7152 - .7152 * s, .0722 + .9278 * s];
    if (k === 'sepia') return [.393 + .607 * s, .769 - .769 * s, .189 - .189 * s, .349 - .349 * s, .686 + .314 * s, .168 - .168 * s, .272 - .272 * s, .534 - .534 * s, .131 + .869 * s];
    if (k === 'hue-rotate') {
      const a = v * Math.PI / 180, c = Math.cos(a), n = Math.sin(a);
      return [.213 + c * .787 - n * .213, .715 - c * .715 - n * .715, .072 - c * .072 + n * .928,
        .213 - c * .213 + n * .143, .715 + c * .285 + n * .140, .072 - c * .072 - n * .283,
        .213 - c * .213 - n * .787, .715 - c * .715 + n * .715, .072 + c * .928 + n * .072];
    }
    return null;
  }
  function applyOps(img, ops) {
    const d = img.data, len = d.length;
    for (const [k, v] of ops) {
      const m = matrixFor(k, v);
      for (let i = 0; i < len; i += 4) {
        let r = d[i], g = d[i + 1], b = d[i + 2];
        if (m) {
          const nr = m[0] * r + m[1] * g + m[2] * b, ng = m[3] * r + m[4] * g + m[5] * b, nb = m[6] * r + m[7] * g + m[8] * b;
          r = nr; g = ng; b = nb;
        } else if (k === 'brightness') { r *= v; g *= v; b *= v; }
        else if (k === 'contrast') { r = (r - 127.5) * v + 127.5; g = (g - 127.5) * v + 127.5; b = (b - 127.5) * v + 127.5; }
        else if (k === 'invert') { r = r + (255 - 2 * r) * v; g = g + (255 - 2 * g) * v; b = b + (255 - 2 * b) * v; }
        d[i] = r; d[i + 1] = g; d[i + 2] = b; // Uint8ClampedArray clamps
      }
    }
  }

  /* ================= Capture ================= */
  function grabFrame(maxW = 1200, src = video, mirror = state.mirror) {
    const vw = src.videoWidth || src.naturalWidth, vh = src.videoHeight || src.naturalHeight;
    if (!vw || !vh) return null;
    // crop to 3:4 portrait like the viewfinder (object-fit: cover)
    let sw = vw, sh = vh;
    if (vw / vh > 3 / 4) sw = vh * 3 / 4; else sh = vw * 4 / 3;
    const sx = (vw - sw) / 2, sy = (vh - sh) / 2;
    const scale = Math.min(1, maxW / sw);
    const w = Math.round(sw * scale), h = Math.round(sh * scale);
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    const g = c.getContext('2d');
    const p = state.preset;
    g.save();
    if (mirror) { g.translate(w, 0); g.scale(-1, 1); }
    if (supportsCtxFilter && p.ops.length) g.filter = presetCss(p);
    g.drawImage(src, sx, sy, sw, sh, 0, 0, w, h);
    g.restore();
    g.filter = 'none';
    if (!supportsCtxFilter && p.ops.length) {
      try { const id = g.getImageData(0, 0, w, h); applyOps(id, p.ops); g.putImageData(id, 0, 0); } catch (e) { console.warn(e); }
    }
    if (p.tint) {
      g.save(); g.globalCompositeOperation = 'soft-light'; g.globalAlpha = p.tint[1];
      g.fillStyle = p.tint[0]; g.fillRect(0, 0, w, h); g.restore();
    }
    if (p.vignette) {
      const r = Math.hypot(w, h) / 2;
      const grd = g.createRadialGradient(w / 2, h / 2, r * 0.52, w / 2, h / 2, r);
      grd.addColorStop(0, 'rgba(0,0,0,0)'); grd.addColorStop(1, `rgba(0,0,0,${p.vignette})`);
      g.save(); g.fillStyle = grd; g.fillRect(0, 0, w, h); g.restore();
    }
    return c;
  }

  function composeStrip(frames) {
    const fw = 480, fh = 640, pad = 28, gap = 18, foot = 110;
    const c = document.createElement('canvas');
    c.width = fw + pad * 2; c.height = pad + frames.length * fh + (frames.length - 1) * gap + foot;
    const g = c.getContext('2d');
    g.fillStyle = '#fffaf0'; g.fillRect(0, 0, c.width, c.height);
    frames.forEach((f, i) => {
      const y = pad + i * (fh + gap);
      g.drawImage(f, 0, 0, f.width, f.height, pad, y, fw, fh);
      g.strokeStyle = '#1f1a24'; g.lineWidth = 4; g.strokeRect(pad, y, fw, fh);
    });
    const fy = c.height - foot + 20;
    g.fillStyle = '#d7263d'; g.textAlign = 'center';
    g.font = '700 46px Chillax, "Trebuchet MS", sans-serif';
    g.fillText('Snap Shack', c.width / 2, fy + 34);
    g.fillStyle = '#4a4250'; g.font = '500 22px "General Sans", sans-serif';
    g.fillText(new Date().toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }), c.width / 2, fy + 70);
    return c;
  }

  function showCount(n) {
    countdownEl.innerHTML = '';
    const el = document.createElement('div');
    el.className = 'num' + (typeof n === 'string' ? ' smile' : '');
    el.textContent = n;
    countdownEl.appendChild(el);
  }

  async function countdown(secs) {
    for (let s = secs; s > 0; s--) {
      if (state.cancel) return false;
      showCount(s);
      beep(s === 1 ? 1175 : 880);
      if (navigator.vibrate) navigator.vibrate(15);
      await sleep(1000);
    }
    if (state.cancel) return false;
    showCount('Smile!');
    await sleep(350);
    return !state.cancel;
  }

  function fireFlash() {
    flash.classList.remove('go'); void flash.offsetWidth; flash.classList.add('go');
    shutterSound();
    if (navigator.vibrate) navigator.vibrate([30, 30, 30]);
  }

  async function capture() {
    if (state.busy) { state.cancel = true; return; }
    if (!(state.cam === 'live' || state.cam === 'demo')) return;
    state.busy = true; state.cancel = false;
    app.classList.add('is-counting');
    shutter.setAttribute('aria-label', 'Cancel countdown');
    [timerBtn, modeBtn, flipBtn].forEach((b) => (b.disabled = true));
    try {
      if (state.mode === 'single') {
        if (state.timer && !(await countdown(state.timer))) { toast('Countdown cancelled'); return; }
        countdownEl.innerHTML = '';
        const frame = grabFrame();
        fireFlash();
        if (frame) await addShot(frame, 'single');
      } else {
        const frames = [];
        stripProgress.innerHTML = '<i></i><i></i><i></i><i></i>';
        for (let i = 0; i < 4; i++) {
          stripProgress.children[i].className = 'now';
          const secs = i === 0 ? (state.timer || 3) : 2;
          if (!(await countdown(secs))) { toast('Strip cancelled'); return; }
          countdownEl.innerHTML = '';
          const f = grabFrame(720);
          fireFlash();
          if (f) frames.push(f);
          stripProgress.children[i].className = 'done';
          await sleep(450);
        }
        if (frames.length) await addShot(composeStrip(frames), 'strip');
      }
    } finally {
      countdownEl.innerHTML = '';
      stripProgress.innerHTML = '';
      app.classList.remove('is-counting');
      shutter.setAttribute('aria-label', 'Take photo');
      [timerBtn, modeBtn, flipBtn].forEach((b) => (b.disabled = false));
      state.busy = false; state.cancel = false;
    }
  }

  /* ================= Native camera fallback (works in any mobile browser / in-app webview) ================= */
  const nativeInput = document.createElement('input');
  nativeInput.type = 'file'; nativeInput.accept = 'image/*'; nativeInput.setAttribute('capture', 'user');
  nativeInput.hidden = true; document.body.appendChild(nativeInput);
  function openNativeCamera() {
    audio();
    nativeInput.setAttribute('capture', state.facing === 'environment' ? 'environment' : 'user');
    nativeInput.value = '';
    nativeInput.click();
  }
  nativeInput.addEventListener('change', async () => {
    const file = nativeInput.files && nativeInput.files[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    const img = new Image();
    try {
      await new Promise((res, rej) => { img.onload = res; img.onerror = rej; img.src = url; });
      if (img.decode) { try { await img.decode(); } catch {} }
      const frame = grabFrame(1200, img, false);
      fireFlash();
      if (frame) {
        await addShot(frame, 'single');
        openViewer(state.shots[0]);
      }
    } catch (e) { console.warn(e); toast('Couldn’t read that photo — try again'); }
    finally { URL.revokeObjectURL(url); }
  });
  $('nativeBtn').addEventListener('click', openNativeCamera);

  /* ================= Gallery ================= */
  function toBlob(canvas) {
    return new Promise((res) => {
      try { canvas.toBlob((b) => res(b), 'image/jpeg', 0.92); }
      catch { res(null); }
    });
  }

  async function addShot(canvas, kind) {
    let blob = await toBlob(canvas);
    let url;
    if (blob) url = URL.createObjectURL(blob);
    else {
      try { url = canvas.toDataURL('image/jpeg', 0.92); } catch { toast('Couldn’t save that one — try again'); return; }
    }
    const date = new Date();
    const shot = { id: Math.random().toString(36).slice(2), url, blob, kind, date, filter: state.preset.name, w: canvas.width, h: canvas.height };
    state.shots.unshift(shot);
    while (state.shots.length > MAX_SHOTS) {
      const old = state.shots.pop();
      if (old.blob) URL.revokeObjectURL(old.url);
    }
    renderGallery(shot.id);
    toast(kind === 'strip' ? 'Strip saved to your gallery' : 'Snap saved — tap it to download');
  }

  function renderGallery(newId) {
    galleryCount.textContent = state.shots.length;
    clearBtn.hidden = state.shots.length === 0;
    if (!state.shots.length) { gallery.replaceChildren(galleryEmpty); return; }
    gallery.replaceChildren(...state.shots.map((s, i) => {
      const li = document.createElement('li');
      li.className = 'shot' + (s.kind === 'strip' ? ' is-strip' : '') + (s.id === newId ? ' new' : '');
      const b = document.createElement('button');
      b.setAttribute('aria-label', `Open ${s.kind === 'strip' ? 'photo strip' : 'photo'} ${i + 1}, ${s.filter} filter`);
      b.innerHTML = `<img src="${s.url}" alt="">`;
      b.addEventListener('click', () => openViewer(s));
      li.appendChild(b);
      return li;
    }));
    gallery.scrollTo({ left: 0, behavior: 'smooth' });
  }

  const canShareFiles = (() => {
    try { return !!(navigator.canShare && navigator.canShare({ files: [new File([new Blob(['x'], { type: 'image/jpeg' })], 'x.jpg', { type: 'image/jpeg' })] })); } catch { return false; }
  })();

  let lastFocus;
  function openViewer(s) {
    state.viewing = s;
    lastFocus = document.activeElement;
    viewerImg.src = s.url;
    viewerImg.alt = s.kind === 'strip' ? 'Captured photo strip' : 'Captured photo';
    viewerMeta.textContent = `${s.kind === 'strip' ? 'Photo strip' : 'Photo'} · ${s.filter} · ${s.date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })} · ${s.w}×${s.h}`;
    dlBtn.href = s.url;
    dlBtn.download = `snapshack-${s.kind}-${stamp(s.date)}.jpg`;
    shareBtn.hidden = !(canShareFiles && s.blob);
    viewer.hidden = false;
    document.body.style.overflow = 'hidden';
    viewer.querySelector('.viewer-close').focus();
  }
  function closeViewer() {
    viewer.hidden = true; state.viewing = null; document.body.style.overflow = '';
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }

  viewer.addEventListener('click', (e) => { if (e.target.closest('[data-close]')) closeViewer(); });
  document.addEventListener('keydown', (e) => {
    if (!viewer.hidden && e.key === 'Escape') closeViewer();
    if (viewer.hidden && e.code === 'Space' && !e.target.closest('button, a, input')) { e.preventDefault(); capture(); }
  });
  dlBtn.addEventListener('click', () => setTimeout(() => toast('Downloading…'), 50));
  shareBtn.addEventListener('click', async () => {
    const s = state.viewing; if (!s || !s.blob) return;
    try {
      await navigator.share({ files: [new File([s.blob], dlBtn.download, { type: 'image/jpeg' })], title: 'Snap Shack' });
    } catch (e) { if (e.name !== 'AbortError') toast('Sharing didn’t work — try Download'); }
  });
  delBtn.addEventListener('click', () => {
    const s = state.viewing; if (!s) return;
    state.shots = state.shots.filter((x) => x.id !== s.id);
    if (s.blob) URL.revokeObjectURL(s.url);
    closeViewer(); renderGallery(); toast('Photo deleted');
  });
  clearBtn.addEventListener('click', () => {
    if (!confirm('Clear all recent shots? Download any you want to keep first.')) return;
    state.shots.forEach((s) => s.blob && URL.revokeObjectURL(s.url));
    state.shots = []; renderGallery(); toast('Gallery cleared');
  });

  /* ================= Controls ================= */
  function setMirror(on) {
    state.mirror = on;
    vf.classList.toggle('mirrored', on);
    mirrorBtn.setAttribute('aria-pressed', on ? 'true' : 'false');
  }
  mirrorBtn.addEventListener('click', () => { setMirror(!state.mirror); updateThumbsSoon(); });
  soundBtn.addEventListener('click', () => {
    state.sound = !state.sound;
    soundBtn.setAttribute('aria-pressed', state.sound ? 'true' : 'false');
    soundBtn.setAttribute('aria-label', state.sound ? 'Sound on' : 'Sound off');
    toast(state.sound ? 'Sound on' : 'Sound off');
    if (state.sound) beep(1000, .08);
  });
  timerBtn.addEventListener('click', () => {
    state.timer = TIMERS[(TIMERS.indexOf(state.timer) + 1) % TIMERS.length];
    timerLabel.textContent = state.timer ? `${state.timer}s` : 'Off';
    timerBtn.classList.toggle('on', state.timer >= 5);
    timerBtn.setAttribute('aria-label', `Countdown: ${state.timer ? state.timer + ' seconds' : 'off'}`);
    toast(state.timer ? `${state.timer}-second countdown` : 'Countdown off — instant snap');
  });
  modeBtn.addEventListener('click', () => {
    state.mode = state.mode === 'single' ? 'strip' : 'single';
    modeBtn.classList.toggle('strip', state.mode === 'strip');
    modeLabel.textContent = state.mode === 'strip' ? 'Strip' : 'Single';
    modeBtn.setAttribute('aria-label', `Mode: ${state.mode === 'strip' ? '4-photo strip' : 'single'}`);
    toast(state.mode === 'strip' ? 'Strip mode: 4 photos in a row' : 'Single photo mode');
  });
  shutter.addEventListener('click', capture);
  flipBtn.addEventListener('click', flipCamera);
  stopBtn.addEventListener('click', () => { state.cancel = true; stopStream(); setCam('idle'); });

  // Save battery when the page is hidden
  document.addEventListener('visibilitychange', () => {
    if (document.hidden && state.cam === 'live') {
      state.cancel = true; stopStream(); setCam('paused');
    }
  });

  // React to permission changes made in browser settings
  async function watchPermission() {
    if (!navigator.permissions || !navigator.permissions.query) return;
    try {
      const p = await navigator.permissions.query({ name: 'camera' });
      p.onchange = () => {
        if (p.state === 'denied' && state.cam === 'live') { stopStream(); setCam('denied'); }
        if (p.state === 'granted' && (state.cam === 'denied')) startCamera();
      };
      if (p.state === 'denied') setCam('denied');
      else if (p.state === 'granted' && navigator.mediaDevices) {
        // Already allowed earlier — open straight away.
        startCamera();
      }
    } catch { /* Safari/Firefox may not support 'camera' query */ }
  }

  /* ================= Boot ================= */
  buildFilters();
  selectPreset(PRESETS[0], false);
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) setCam('unsupported');
  else { setCam('idle'); watchPermission(); }
  if (navigator.mediaDevices && navigator.mediaDevices.addEventListener) {
    navigator.mediaDevices.addEventListener('devicechange', () => { if (state.cam === 'live') refreshDevices(); });
  }
})();
